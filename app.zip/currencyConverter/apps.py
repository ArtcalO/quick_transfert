from django.apps import AppConfig


class CurrencyconverterConfig(AppConfig):
    name = 'currencyConverter'
